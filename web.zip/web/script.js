// let qtd =  parseInt(window.prompt("Digite Quantidade: "));
// let numero= "*";
// let soma = numero;
// for (let i = 0; i <=qtd; i++){

  
   // console.log(soma);
    //soma += numero;
// }


// para fazer uma piramide 

//let qtd =  parseInt(window.prompt("Digite Quantidade: "));
//let numero= 0;
//let soma = 0;

//for (let i = 0; i <qtd; i++){

  //  numero = numero * 10 + 1;
    //console.log("Numero:", numero);
    //soma += numero;
//}
//console.log("Soma:" , soma);


// para somar um numero 1 11 111
